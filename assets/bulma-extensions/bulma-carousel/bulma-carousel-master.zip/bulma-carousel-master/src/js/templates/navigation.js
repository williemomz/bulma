export default (icons) => {
	return `<div class="slider-navigation-previous">${icons.previous}</div>
<div class="slider-navigation-next">${icons.next}</div>`;
};