export default () => {
  return `<div class="slider-page"></div>`;
};